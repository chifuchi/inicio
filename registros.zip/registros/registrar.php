<?php
//Post para viajar en metodo oculto
$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];
$edad=$_POST['edad'];
$direccion=$_POST['direccion'];
//Coneccion a base de datos
$conexion=mysqli_connect("sql112.infinityfree.com","if0_38935609","UBVibw9G3lfv","if0_38935609_bdejemplo");

//ingresar datos
$consulta= "insert into cliente values($codigo,'$nombre',$edad,'$direccion')";

$resultado= mysqli_query($conexion,$consulta);

if($resultado)
{

    echo "Datos agregados correctamente";
      header("Location: mostrar_clientes.php");
    exit(); // Asegúrate de detener la ejecución del script después de la redirección

}

else
{
    echo "Error al ingresar los datos";
}

mysqli_close($conexion);
