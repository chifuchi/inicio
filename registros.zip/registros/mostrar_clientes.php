<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Clientes</title>
    <link rel="stylesheet" href="estilos_grid.css">
    <style>
        .client-row {
            display: flex;
            border-bottom: 1px solid #eee; /* Separador entre filas */
            padding: 8px 0;
            align-items: center;
        }

        .client-row:last-child {
            border-bottom: none; /* Sin separador en la última fila */
        }

        .client-column {
            flex: 1; /* Distribuye el espacio de manera uniforme entre las columnas */
            padding-right: 10px;
        }

        .client-column:last-child {
            padding-right: 0;
        }

        .actions {
            display: flex;
            gap: 5px;
            justify-content: flex-end; /* Alinea los botones a la derecha */
            min-width: 150px; /* Asegura espacio para los botones */
        }

        .actions a, .actions button {
            padding: 5px 8px;
            text-decoration: none;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 3px;
            font-size: 0.8em;
        }

        .actions .eliminar {
            background-color: #dc3545;
        }

        .actions .modificar {
            background-color: #007bff;
        }

        .header {
            display: flex;
            border-bottom: 2px solid #ccc;
            padding: 8px 0;
            font-weight: bold;
        }

        .header .client-column {
            flex: 1;
            padding-right: 10px;
        }

        .header .actions {
            justify-content: flex-end;
        }
         p a.button-link { /* Aplica la clase 'button-link' al enlace */
        display: inline-block; /* Permite establecer ancho y alto */
        padding: 5px 10px; /* Espaciado interior */
        text-decoration: none; /* Elimina el subrayado */
        color: white; /* Color del texto */
        border: none; /* Elimina el borde */
        cursor: pointer; /* Cambia el cursor al pasar por encima */
        border-radius: 3px; /* Bordes redondeados */
        font-size: 0.8em; /* Tamaño de la fuente (ajusta si es necesario) */
        background-color: green; /* Color de fondo (puedes elegir otro) */
    }

    p a.button-link:hover { /* Estilo al pasar el ratón (opcional) */
        opacity: 0.8; /* Reduce la opacidad para un efecto visual */
    }

    </style>
</head>
<body>

    <h1>Lista de Clientes</h1>
   
    <p><a href="registro.html" class="button-link">Ir a Registro de Clientes</a></p>
    <div class="header">
        <div class="client-column">Código</div>
        <div class="client-column">Nombre</div>
        <div class="client-column">Edad</div>
        <div class="client-column">Dirección</div>
        <div class="client-column actions">Acciones</div>
    </div>

    <?php
        // Conexión a la base de datos (ajusta los datos si es necesario)
        $conexion = mysqli_connect("localhost", "root", "", "bdejemplo");

        // Verificar la conexión
        if (!$conexion) {
            die("Error al conectar a la base de datos: " . mysqli_connect_error());
        }

        // Consulta para obtener los datos de la tabla cliente
        $consulta = "SELECT codigo, nombre, edad, direccion FROM cliente";
        $resultado = mysqli_query($conexion, $consulta);

        // Mostrar los datos como filas y columnas
        if (mysqli_num_rows($resultado) > 0) {
            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<div class='client-row'>";
                echo "<div class='client-column'>" . $fila["codigo"] . "</div>";
                echo "<div class='client-column'>" . $fila["nombre"] . "</div>";
                echo "<div class='client-column'>" . $fila["edad"] . "</div>";
                echo "<div class='client-column'>" . $fila["direccion"] . "</div>";
                echo "<div class='client-column actions'>";
                echo "<a href='modificar_cliente.php?codigo=" . $fila["codigo"] . "' class='modificar'>Modificar</a>";
                echo "<button onclick='eliminarCliente(" . $fila["codigo"] . ")' class='eliminar'>Eliminar</button>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='client-row'><div class='client-column colspan-5'>No se encontraron clientes registrados.</div></div>";
        }

        // Cerrar la conexión
        mysqli_close($conexion);
    ?>

    <script>
        function eliminarCliente(codigo) {
            if (confirm('¿Estás seguro de que deseas eliminar este cliente?')) {
                window.location.href = 'eliminar_cliente.php?codigo=' + codigo;
            }
        }
    </script>

</body>
</html>