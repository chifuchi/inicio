<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Cliente</title>
    <link rel="stylesheet" href="estilos.css">
    
</head>
<body>
    <div class="formulario-container">
        <h1>Modificar Cliente</h1>
        <?php
            // Verificar si se recibió el código del cliente a modificar
            if (isset($_GET['codigo']) && !empty($_GET['codigo'])) {
                $codigo_cliente = $_GET['codigo'];

                // Conexión a la base de datos (ajusta los datos si es necesario)
                $conexion = mysqli_connect("localhost", "root", "", "bdejemplo");

                // Verificar la conexión
                if (!$conexion) {
                    die("Error al conectar a la base de datos: " . mysqli_connect_error());
                }

                // Consulta para obtener los datos del cliente a modificar
                $consulta = "SELECT codigo, nombre, edad, direccion FROM cliente WHERE codigo = $codigo_cliente";
                $resultado = mysqli_query($conexion, $consulta);

                if (mysqli_num_rows($resultado) == 1) {
                    $fila = mysqli_fetch_assoc($resultado);
                    ?>
                    <form action="procesar_modificacion.php" method="post">
                        <input type="hidden" name="codigo_original" value="<?php echo $fila['codigo']; ?>">
                        <label for="codigo">Código:</label>
                        <input type="text" name="codigo" id="codigo" value="<?php echo $fila['codigo']; ?>" readonly>
                        <br>
                        <label for="nombre">Nombre:</label>
                        <input type="text" name="nombre" id="nombre" value="<?php echo $fila['nombre']; ?>" required>
                        <br>
                        <label for="edad">Edad:</label>
                        <input type="number" name="edad" id="edad" value="<?php echo $fila['edad']; ?>" required>
                        <br>
                        <label for="direccion">Dirección:</label>
                        <input type="text" name="direccion" id="direccion" value="<?php echo $fila['direccion']; ?>" required>
                        <br>
                        <button type="submit">Guardar Cambios</button>
                    </form>
                    <a href="mostrar_clientes.php" class="volver">Volver a la Lista</a>
                    <?php
                } else {
                    echo "<p>No se encontró el cliente con el código proporcionado.</p>";
                    echo "<p><a href='mostrar_clientes.php' class='volver'>Volver a la Lista</a></p>";
                }

                // Cerrar la conexión
                mysqli_close($conexion);
            } else {
                echo "<p>No se proporcionó el código del cliente a modificar.</p>";
                echo "<p><a href='mostrar_clientes.php' class='volver'>Volver a la Lista</a></p>";
            }
        ?>
    </div>
</body>
</html>