<?php
    // Verificar si se recibió el código del cliente a eliminar
    if (isset($_GET['codigo']) && !empty($_GET['codigo'])) {
        $codigo_cliente = $_GET['codigo'];

        // Conexión a la base de datos (ajusta los datos si es necesario)
        $conexion = mysqli_connect("localhost", "root", "", "bdejemplo");

        // Verificar la conexión
        if (!$conexion) {
            die("Error al conectar a la base de datos: " . mysqli_connect_error());
        }

        // Consulta para eliminar el cliente
        $consulta = "DELETE FROM cliente WHERE codigo = $codigo_cliente";

        if (mysqli_query($conexion, $consulta)) {
            echo "<script>alert('Cliente eliminado correctamente.'); window.location.href='mostrar_clientes.php';</script>";
        } else {
            echo "<script>alert('Error al eliminar el cliente: " . mysqli_error($conexion) . "'); window.location.href='mostrar_clientes.php';</script>";
        }

        // Cerrar la conexión
        mysqli_close($conexion);
    } else {
        echo "<script>alert('No se proporcionó el código del cliente a eliminar.'); window.location.href='mostrar_clientes.php';</script>";
    }
?>