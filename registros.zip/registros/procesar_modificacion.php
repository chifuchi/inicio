<?php
    // Verificar si se recibieron los datos del formulario
    if (isset($_POST['codigo_original']) && !empty($_POST['codigo_original']) &&
        isset($_POST['codigo']) && !empty($_POST['codigo']) &&
        isset($_POST['nombre']) && !empty($_POST['nombre']) &&
        isset($_POST['edad']) && !empty($_POST['edad']) &&
        isset($_POST['direccion']) && !empty($_POST['direccion'])) {

        $codigo_original = $_POST['codigo_original'];
        $codigo = $_POST['codigo'];
        $nombre = $_POST['nombre'];
        $edad = $_POST['edad'];
        $direccion = $_POST['direccion'];

        // Conexión a la base de datos (ajusta los datos si es necesario)
        $conexion = mysqli_connect("localhost", "root", "", "bdejemplo");

        // Verificar la conexión
        if (!$conexion) {
            die("Error al conectar a la base de datos: " . mysqli_connect_error());
        }

        // Consulta para actualizar los datos del cliente
        $consulta = "UPDATE cliente SET codigo = '$codigo', nombre = '$nombre', edad = $edad, direccion = '$direccion' WHERE codigo = $codigo_original";

        if (mysqli_query($conexion, $consulta)) {
            echo "<script>alert('Datos del cliente actualizados correctamente.'); window.location.href='mostrar_clientes.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar los datos del cliente: " . mysqli_error($conexion) . "'); window.location.href='mostrar_clientes.php';</script>";
        }

        // Cerrar la conexión
        mysqli_close($conexion);
    } else {
        echo "<script>alert('No se recibieron todos los datos del formulario.'); window.location.href='mostrar_clientes.php';</script>";
    }
?>